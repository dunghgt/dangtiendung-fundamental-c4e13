c = int(input("Enter the temprature in Celcius : "))
f = c * 1.8000 + 32
print(c, "(C)", = f, "(F)")
