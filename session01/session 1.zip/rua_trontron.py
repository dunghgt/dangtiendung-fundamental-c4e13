from turtle import *

shape("turtle")

speed(-1)

for i in range(20):
    circle(100)
    right(30)

mainloop()
