r = int(input("Radius? "))
area = 3.14 * r * r
print("area = ", area)
