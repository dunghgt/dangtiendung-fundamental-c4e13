from turtle import *

shape("turtle")

circle(100)

mainloop()
